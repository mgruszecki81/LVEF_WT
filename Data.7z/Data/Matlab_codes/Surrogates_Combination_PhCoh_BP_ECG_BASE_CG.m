clear all;
close all;

% WAVELET PARAMETERS

fs=20;
f_max=5;

% main loop

numfiles = 10;
mydata = cell(1, numfiles);

for k = 1:numfiles

  myfilename = sprintf('BP_ECG_SUB%d_fs20_BASE_CG.dat', k);
  mydata{k} = importdata(myfilename);

  BP(:,k)=mydata{k}(:,1);
  ECG(:,k)=mydata{k}(:,2);

end

% MAIN LOOP

for i=1:numfiles

   [WT_BP1,freq1]=wt(BP(:,i),fs,'fmax',f_max,'Plot','off','Wavelet','Morlet','Preprocess','off');
   print_i=i

  for j=1:numfiles

  if j==i
  continue;
  end

   print_i=i
   print_j=j

   [WT_ECG1,freq1]=wt(ECG(:,j),fs,'fmax',f_max,'Plot','off','Wavelet','Morlet','Preprocess','off');
   [phcoh_BP_ECG1(i,j,:)] = wphcoh(WT_BP1,WT_ECG1);

  end
end

phcoh_BP_ECG1(phcoh_BP_ECG1==0)=NaN;

phcoh_BP_ECG_NaN_vec = reshape(phcoh_BP_ECG1,[],1,length(freq1));
phcoh_BP_ECG_av_NaN=nanmean(phcoh_BP_ECG_NaN_vec);
phcoh_BP_ECG_std_NaN=nanstd(phcoh_BP_ECG_NaN_vec);
phcoh_BP_ECG_prc_NaN=prctile(phcoh_BP_ECG_NaN_vec,95);

phcoh_BP_ECG_av_NaN=permute(phcoh_BP_ECG_av_NaN,[3,1,2]);
phcoh_BP_ECG_std_NaN=permute(phcoh_BP_ECG_std_NaN,[3,1,2]);
phcoh_BP_ECG_prc_NaN=permute(phcoh_BP_ECG_prc_NaN,[3,1,2]);


new=[freq1 phcoh_BP_ECG_av_NaN phcoh_BP_ECG_std_NaN phcoh_BP_ECG_prc_NaN];
save freq_Mean_STD_Prc95_PhCoh_BP_ECG_Surrog_10SUB_CG.dat new -ascii -single

semilogx(freq1, phcoh_BP_ECG_av_NaN, '-r'); hold on
semilogx(freq1, phcoh_BP_ECG_av_NaN+2*phcoh_BP_ECG_std_NaN, '-b');

semilogx(freq1, phcoh_BP_ECG_prc_NaN, '-g');
legend('Surr','Surr+2*STD','Perc. 95')

print -djpeg Surrogate_Plot_PhCoh_BP_ECG_CG.jpeg -r400



