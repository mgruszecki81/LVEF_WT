%cd ../../../../../
%cd users\mgruszecki\desktop\Recenzja\Uwaga3_Rec2

clear all;
close all;


numfiles = 10;
mydata = cell(1, numfiles);

% main loop

for k = 1:numfiles

close all;
clearvars -except numfiles mydata k;


  myfilename = sprintf('BP_ECG_SUB%d_fs20_BASE_CG.dat', k);
  mydata{k} = importdata(myfilename);

  BP=mydata{k}(:,1);
  ECG=mydata{k}(:,2);

n_BP=length(BP);

% sampling frequency - cz�stotliwo�� zapisu analizowanego sygna�u

fs=20;
T_BP=n_BP/fs;

t_BP=0:1/fs:T_BP-1/fs;

% minimal frequency - cz�stotliwo�� minimalna dla kt�rej analizowany jest zebrany sygna�

%f_min=0.005;

% maximal frequency - cz�stotliwo�� maksymalna dla kt�rej analizowany jest zebrany sygna�

f_max=5;

%**********************BP******************************

[WT_BP,freq_BP]=wt(BP,fs,'fmax',f_max,'Plot','amp++','CutEdges','on','Wavelet','Morlet','Preprocess','off');
eval(['print -djpeg WT_BP_SUB' num2str(k) '_Norm_DeT_BASE_CT.jpeg -r400']);


% ESTIMATION OF AVERAGE AND STANDARD DEVIATION 

% calculate amplitude of WT

% WT Amplitude
WT_BP_AMP=abs(WT_BP);

% WT Power
%WT_BP_AMP=abs(WT_BP).^2;

% replace NaN's by 0

WT_BP_AMP(isnan(WT_BP_AMP))=0;

n_WT_BP=size(WT_BP_AMP); n_WT_BP_x=n_WT_BP(1,1); n_WT_BP_y=n_WT_BP(1,2); 

for i=1:n_WT_BP_x

NL=length(find(WT_BP_AMP(i,:)==0));

WT_BP_mean(i)=sum(WT_BP_AMP(i,:))/(n_WT_BP_y-NL);
std_WT_BP(i)=sqrt(sum((WT_BP_AMP(i,:)-WT_BP_mean(i)).^2)/(n_WT_BP_y-NL-1));

end

figure; semilogx(freq_BP,WT_BP_mean,'-r'); xlabel('Frequency (Hz)'); ylabel('Time average of WT'); 
eval(['print -djpeg WTAmp_AV_BP_SUB' num2str(k) '_Norm_DeT_BASE_CT.jpeg -r400']);


% save to file

new=[freq_BP WT_BP_mean' std_WT_BP'];
eval(['save freq_avWTAmp_stdWTAmp_BP_SUB' num2str(k) '_Norm_DeT_BASE_CT.dat new -ascii']);

%**********************ECG******************************

[WT_ECG,freq_ECG]=wt(ECG,fs,'fmax',f_max,'Plot','amp++','CutEdges','on','Wavelet','Morlet','Preprocess','off');
eval(['print -djpeg WT_ECG_SUB' num2str(k) '_Norm_DeT_BASE_CT.jpeg -r400']);


% ESTIMATION OF AVERAGE AND STANDARD DEVIATION 

% calculate amplitude of WT

% WT Amplitude
WT_ECG_AMP=abs(WT_ECG);

% WT Power
%WT_ECG_AMP=abs(WT_ECG).^2;

% replace NaN's by 0

WT_ECG_AMP(isnan(WT_ECG_AMP))=0;

n_WT_ECG=size(WT_ECG_AMP); n_WT_ECG_x=n_WT_ECG(1,1); n_WT_ECG_y=n_WT_ECG(1,2); 

for i=1:n_WT_ECG_x

NL=length(find(WT_ECG_AMP(i,:)==0));

WT_ECG_mean(i)=sum(WT_ECG_AMP(i,:))/(n_WT_ECG_y-NL);
std_WT_ECG(i)=sqrt(sum((WT_ECG_AMP(i,:)-WT_ECG_mean(i)).^2)/(n_WT_ECG_y-NL-1));

end

figure; semilogx(freq_ECG,WT_ECG_mean,'-r'); xlabel('Frequency (Hz)'); ylabel('Time average of WT'); 
eval(['print -djpeg WTAmp_AV_ECG_SUB' num2str(k) '_Norm_DeT_BASE_CT.jpeg -r400']);


% save to file

new=[freq_ECG WT_ECG_mean' std_WT_ECG'];
eval(['save freq_avWTAmp_stdWTAmp_ECG_SUB' num2str(k) '_Norm_DeT_BASE_CT.dat new -ascii']);

end
