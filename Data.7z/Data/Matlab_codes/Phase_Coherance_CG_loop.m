clear all;
close all;

% main loop

numfiles = 10;
mydata = cell(1, numfiles);

for k = 1:numfiles

close all;
clearvars -except numfiles mydata k;

Number_of_file=k

  myfilename = sprintf('BP_ECG_SUB%d_fs20_BASE_CG.dat', k);
  mydata{k} = importdata(myfilename);

  BP_fs20=mydata{k}(:,1);
  ECG_fs20=mydata{k}(:,2);

% sampling frequency

n=length(BP_fs20);
fs=20;
T=n/fs;

t=0:1/fs:T-1/fs;

f_max=4;

% Calculate WT for all variables

   [WT_BP,freq]=wt(BP_fs20,fs,'fmax',f_max,'Plot','amp++','CutEdges','on','Wavelet','Morlet','Preprocess','off');
   [WT_ECG,freq]=wt(ECG_fs20,fs,'fmax',f_max,'Plot','amp++','CutEdges','on','Wavelet','Morlet','Preprocess','off');

%***************************PHASE COHERENCE - BP and ECG***************************

   [phcoh_BP_ECG,phdiff_BP_ECG] = wphcoh(WT_BP,WT_ECG);

% plot Ph. Coher and Ph. Diff.
   
figure; 
subplot(2,1,1); semilogx(freq,phcoh_BP_ECG,'-r'); xlabel('Frequency [Hz]'); ylabel('Ph. Coher.'); xlim([0.009,2]); ylim([-0.1,1.1]);
subplot(2,1,2); semilogx(freq,phdiff_BP_ECG*180/pi,'-b'); xlabel('Frequency [Hz]'); ylabel('Ph. Diff.'); xlim([0.009,2]); ylim([-200,200]);

eval(['print -djpeg PhCoh_BP_ECG_SUB' num2str(k) '_BASE_CG.jpeg -r400']);

% save to file 

   new=[freq phcoh_BP_ECG' (phdiff_BP_ECG*180/pi)'];
   filename = [ 'PhCoh_BP_ECG_SUB', num2str(k),'_BASE_CG.dat' ];
   save(filename,'new', '-ascii');

end



